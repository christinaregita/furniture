package mii.co.id.servertrainingmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerTrainingManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
