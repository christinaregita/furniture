package mii.co.id.clienttrainingmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientTrainingManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
